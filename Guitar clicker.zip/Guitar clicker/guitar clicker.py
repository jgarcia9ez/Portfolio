# =============================================================
# GUITAR CLICKER  v3  —  Edición Profesional
# Inspired by Cookie Clicker
#
# pip install pygame
# python main.py
#
# Pon guitar.jpg en la misma carpeta que main.py
# =============================================================

import pygame
import random
import sys
import math
import os
import json
from typing import Dict, List, Optional

pygame.init()
pygame.mixer.init()

# =============================================================
# RUTA BASE
# =============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# =============================================================
# CONFIG
# =============================================================

ANCHO = 1280
ALTO  = 720
FPS   = 60

SAVE_FILE = os.path.join(BASE_DIR, "save.json")

pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Guitar Clicker v3")
reloj = pygame.time.Clock()

# =============================================================
# FUENTES
# =============================================================

fuente_titulo  = pygame.font.SysFont("Arial", 40, bold=True)
fuente_grande  = pygame.font.SysFont("Arial", 30, bold=True)
fuente         = pygame.font.SysFont("Arial", 21, bold=True)
fuente_pequena = pygame.font.SysFont("Arial", 16, bold=True)
fuente_mini    = pygame.font.SysFont("Arial", 13)
fuente_micro   = pygame.font.SysFont("Arial", 11)

# =============================================================
# COLORES
# =============================================================

FONDO    = (8,   12,  24)
PANEL    = (14,  21,  44)
PANEL2   = (24,  35,  66)
PANEL3   = (17,  27,  50)
PANEL_RB = (35,  18,  55)   # rebirth panel color

AZUL     = (0,   200, 255)
VERDE    = (0,   255, 160)
AMARILLO = (255, 220,   0)
ROJO     = (255,  80,  80)
MORADO   = (180,  80, 255)
NARANJA  = (255, 140,   0)
CYAN     = (0,   240, 220)
ROSA     = (255, 100, 180)
ORO      = (255, 200,  50)

BLANCO   = (255, 255, 255)
GRIS     = (145, 145, 170)
GRIS_O   = (60,   60,  88)

# =============================================================
# RUTAS
# =============================================================

RUTA_GUITAR = os.path.join(BASE_DIR, "guitar.jpg")

RUTA_NINOS = [os.path.join(BASE_DIR, "niño.png")]

def _ruta(nombre):
    return os.path.join(BASE_DIR, nombre)

ICONOS = {
    # Click
    "Microfono":        _ruta("mic.webp"),
    "Miniatura":        _ruta("miniatura.webp"),
    "PC":               _ruta("pc.png"),
    "Cam 4K":           _ruta("cam4k.png"),
    "Estudio":          _ruta("estudio.png"),
    "Sello Disquero":   _ruta("sello.png"),
    # CPS
    "Sub":              _ruta("sub.webp"),
    "Editor":           _ruta("editor.png"),
    "Canal":            _ruta("canal.png"),
    "Stream":           _ruta("stream.png"),
    "Agencia":          _ruta("agencia.png"),
    "Tour Mundial":     _ruta("tour.png"),
    # Token
    "Niño noob":        _ruta("noob.png"),
    "Niño pro":         _ruta("pro.png"),
    "Niño hacker":      _ruta("hacker.png"),
    "Niño dios":        _ruta("dios.png"),
    "Niño legendario":  _ruta("legendario.png"),
    # Global
    "Cuerdas de Oro":   _ruta("cuerdas.png"),
    "Amplificador":     _ruta("amplificador.png"),
    "Pedal Wah":        _ruta("pedal.png"),
    "Arena Rock":       _ruta("arena.png"),
    # Prestige (rebirth permanente)
    "Estrella de Rock": _ruta("estrella.png"),
    "Leyenda Viral":    _ruta("leyenda.png"),
    "Dios del Guitar":  _ruta("diosg.png"),
}

# =============================================================
# CACHE IMÁGENES
# =============================================================

_img_cache: dict = {}
_FB_COLS = [
    (120,  0, 200),(0, 140, 200),(180, 80,   0),
    (0,  160,  80),(160,  0,  0),(80,  80, 180),
    (180,160,   0),(0,  180, 160),(140, 0, 140),
    (200, 80,   0),(0,  120, 180),(80, 160,   0),
]
_fbi = 0

def cargar_imagen(path, size):
    global _fbi
    key = (path, size)
    if key in _img_cache:
        return _img_cache[key]
    try:
        img = pygame.image.load(path).convert_alpha()
        img = pygame.transform.smoothscale(img, size)
    except Exception:
        img = pygame.Surface(size, pygame.SRCALPHA)
        col = _FB_COLS[_fbi % len(_FB_COLS)]
        _fbi += 1
        img.fill(col)
        pygame.draw.rect(img, (210, 210, 210), img.get_rect(), 2)
        name = os.path.basename(path)
        letra = name[0].upper() if name else "?"
        lbl = fuente_pequena.render(letra, True, (255, 255, 255))
        img.blit(lbl, (size[0]//2 - lbl.get_width()//2,
                       size[1]//2 - lbl.get_height()//2))
    _img_cache[key] = img
    return img

img_guitar_orig = cargar_imagen(RUTA_GUITAR, (300, 300))

# =============================================================
# HELPERS
# =============================================================

def fmt(n: float) -> str:
    n = float(n)
    if n >= 1e18: return f"{n/1e18:.2f}Qi"
    if n >= 1e15: return f"{n/1e15:.2f}Qa"
    if n >= 1e12: return f"{n/1e12:.2f}T"
    if n >= 1e9:  return f"{n/1e9:.2f}B"
    if n >= 1e6:  return f"{n/1e6:.2f}M"
    if n >= 1e3:  return f"{n/1e3:.1f}K"
    return str(int(n))

def blit_shadow(surf, text, font, color, pos,
                offset=2, shadow=(0,0,0)):
    s = font.render(text, True, shadow)
    surf.blit(s, (pos[0]+offset, pos[1]+offset))
    s = font.render(text, True, color)
    surf.blit(s, pos)
    return s.get_rect(topleft=pos)

def draw_panel(surf, rect, fill, border=None, bw=2, r=12):
    pygame.draw.rect(surf, fill, rect, border_radius=r)
    if border:
        pygame.draw.rect(surf, border, rect, bw, border_radius=r)

def lerp_color(a, b, t):
    return tuple(int(a[i] + (b[i]-a[i])*t) for i in range(3))

# =============================================================
# LAYOUT
# =============================================================

LEFT_W   = 342
RIGHT_W  = 342
RIGHT_X  = ANCHO - RIGHT_W
CENTER_X = LEFT_W
CENTER_W = ANCHO - LEFT_W - RIGHT_W   # 596

GX = CENTER_X + CENTER_W // 2
GY = ALTO // 2
GUITAR_HIT_R = 145

ARENA_X1  = LEFT_W + 6
ARENA_X2  = RIGHT_X - 6
ARENA_Y1  = 6
ARENA_Y2  = ALTO - 6
NINO_SIZE = 56

SPAWN_INTERVAL = 10 * FPS   # 1 niño cada 10 s (frames)
MAX_NINOS      = 10

# =============================================================
# PARTÍCULA
# =============================================================

class Particle:
    def __init__(self, x, y, color, speed_mult=1.0):
        self.x    = float(x)
        self.y    = float(y)
        ang       = random.uniform(0, math.tau)
        spd       = random.uniform(2.5, 5.5) * speed_mult
        self.vx   = math.cos(ang) * spd
        self.vy   = math.sin(ang) * spd
        self.life = random.randint(20, 40)
        self.maxl = self.life
        self.col  = color
        self.size = random.randint(3, 7)

    def update(self):
        self.x  += self.vx
        self.y  += self.vy
        self.vy += 0.14
        self.vx *= 0.96
        self.life -= 1

    def draw(self, surf):
        a = int(255 * self.life / self.maxl)
        r = max(1, int(self.size * self.life / self.maxl))
        s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*self.col, a), (r, r), r)
        surf.blit(s, (int(self.x)-r, int(self.y)-r))

# =============================================================
# TEXTO FLOTANTE
# =============================================================

class FloatingText:
    def __init__(self, text, x, y, color, big=False):
        self.text  = text
        self.x     = float(x)
        self.y     = float(y)
        self.color = color
        self.life  = 65
        self.font  = fuente_grande if big else fuente_pequena
        self.vx    = random.uniform(-0.5, 0.5)

    def update(self):
        self.y    -= 1.2
        self.x    += self.vx
        self.life -= 1

    def draw(self, surf):
        a = min(255, int(self.life * 4.2))
        s = self.font.render(self.text, True, self.color)
        s.set_alpha(a)
        surf.blit(s, (int(self.x) - s.get_width()//2, int(self.y)))

# =============================================================
# NIÑO
# =============================================================

class Nino:
    TIER_DATA = [
        # nombre,       borde,               vmin, vmax, prob_acum
        ("noob",       ( 80, 200,  80),        1,    5,   0.50),
        ("pro",        ( 80, 160, 255),        5,   15,   0.30),
        ("hacker",     (190,  80, 255),       15,   45,   0.14),
        ("dios",       (255, 200,   0),       45,  130,   0.05),
        ("legendario", (255, 100,  50),      130,  500,   0.01),
    ]

    def __init__(self, rebirth_bonus=1.0, tier_idx=None):
        if tier_idx is None:
            r   = random.random()
            cum = 0.0
            tier_idx = len(self.TIER_DATA) - 1
            for i, td in enumerate(self.TIER_DATA):
                cum += td[4]
                if r < cum:
                    tier_idx = i
                    break

        td = self.TIER_DATA[tier_idx]
        self.tier_idx   = tier_idx
        self.tier_name  = td[0]
        self.border_col = td[1]
        self.valor      = int(random.randint(td[2], td[3]) * rebirth_bonus)

        mg      = NINO_SIZE + 4
        self.x  = float(random.randint(ARENA_X1 + mg, ARENA_X2 - mg))
        self.y  = float(random.randint(ARENA_Y1 + mg, ARENA_Y2 - mg))

        spd     = random.uniform(1.0, 2.4) + tier_idx * 0.3
        ang     = random.uniform(0, math.tau)
        self.vx = math.cos(ang) * spd
        self.vy = math.sin(ang) * spd

        self.img    = cargar_imagen(random.choice(RUTA_NINOS),
                                    (NINO_SIZE, NINO_SIZE))
        self.rect   = pygame.Rect(int(self.x), int(self.y), NINO_SIZE, NINO_SIZE)
        self._hsc   = 1.0
        self._blink = 0

    def update(self, mx, my):
        self.x += self.vx;  self.y += self.vy

        if self.x < ARENA_X1:              self.x = ARENA_X1;              self.vx =  abs(self.vx)
        if self.x > ARENA_X2 - NINO_SIZE:  self.x = ARENA_X2 - NINO_SIZE;  self.vx = -abs(self.vx)
        if self.y < ARENA_Y1:              self.y = ARENA_Y1;              self.vy =  abs(self.vy)
        if self.y > ARENA_Y2 - NINO_SIZE:  self.y = ARENA_Y2 - NINO_SIZE;  self.vy = -abs(self.vy)

        self.rect.topleft = (int(self.x), int(self.y))
        hover = self.rect.collidepoint(mx, my)
        self._hsc  = min(1.22, self._hsc + 0.05) if hover else max(1.0, self._hsc - 0.05)
        self._blink = (self._blink + 1) % 40

    def draw(self, surf):
        sz  = int(NINO_SIZE * self._hsc)
        img = pygame.transform.smoothscale(self.img, (sz, sz)) if self._hsc != 1.0 else self.img
        cx  = int(self.x + NINO_SIZE//2)
        cy  = int(self.y + NINO_SIZE//2)
        surf.blit(img, (cx - sz//2, cy - sz//2))
        bc  = (255, 255, 255) if self.tier_idx == 4 and self._blink < 20 else self.border_col
        pygame.draw.rect(surf, bc, self.rect, 2, border_radius=6)
        badge = fuente_mini.render(f"+{fmt(self.valor)}", True, AMARILLO)
        surf.blit(badge, (cx - badge.get_width()//2, int(self.y) - 18))

# =============================================================
# UPGRADE
# =============================================================

class Upgrade:
    def __init__(self, name, base_cost, multiplier, power,
                 tipo, desc=""):
        self.name       = name
        self.base_cost  = base_cost
        self.multiplier = multiplier
        self.power      = power
        self.tipo       = tipo   # click | cps | token | global | prestige
        self.desc       = desc
        self.level      = 0
        self.img        = cargar_imagen(ICONOS.get(name, ""), (50, 50))

    def cost(self, rebirth_discount=1.0) -> int:
        return max(1, int(self.base_cost * (self.multiplier ** self.level)
                          * rebirth_discount))

    def to_dict(self):
        return {"level": self.level}

    def from_dict(self, d):
        self.level = int(d.get("level", 0))

# =============================================================
# BOTÓN DE TIENDA
# =============================================================

SHOP_W   = 308
SHOP_H   = 80
SHOP_PAD = 4
ICON_SZ  = 50

_TIPO_COLOR = {
    "click":    AZUL,
    "cps":      VERDE,
    "token":    AMARILLO,
    "global":   MORADO,
    "prestige": ORO,
}

class ShopButton:
    def __init__(self, upg: Upgrade):
        self.upg  = upg
        self.rect = pygame.Rect(0, 0, SHOP_W, SHOP_H)

    def reposition(self, x, y):
        self.rect.topleft = (x, y)

    def draw(self, surf, can_buy, hovered, cam_active, rebirth_glow=False):
        upg = self.upg
        r   = self.rect

        if hovered and can_buy:   fill = (45, 125, 85)
        elif can_buy:             fill = (30,  88, 58)
        elif hovered:             fill = (36,  46, 82)
        else:                     fill = PANEL2

        tc = _TIPO_COLOR.get(upg.tipo, GRIS_O)
        border = tc if can_buy else GRIS_O
        draw_panel(surf, r, fill, border, 2, 11)
        pygame.draw.rect(surf, tc, (r.x, r.y, 4, r.h), border_radius=3)

        surf.blit(upg.img, (r.x + SHOP_PAD + 5,
                             r.y + (SHOP_H - ICON_SZ)//2))

        tx = r.x + ICON_SZ + SHOP_PAD * 3 + 6
        ty = r.y + 6

        blit_shadow(surf, upg.name, fuente_pequena, BLANCO, (tx, ty))
        lvl = fuente_pequena.render(f"Lv{upg.level}", True, AMARILLO)
        surf.blit(lvl, (r.right - lvl.get_width() - 6, ty))

        moneda   = "TK" if upg.tipo == "token" else "CP"
        col_cost = VERDE if can_buy else ROJO
        blit_shadow(surf, f"{fmt(upg.cost())} {moneda}",
                    fuente_mini, col_cost, (tx, ty + 24))

        if upg.tipo == "click":
            gt = f"+{upg.power} CP/click"
        elif upg.tipo == "cps":
            gt = f"+{upg.power} CP/s"
        elif upg.tipo == "token":
            gt = f"+{int(upg.power*100)}% multi"
        else:
            gt = upg.desc

        blit_shadow(surf, gt, fuente_mini, CYAN, (tx, ty + 44))

        if cam_active:
            g = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            g.fill((0, 200, 255, 18))
            surf.blit(g, r.topleft)

        if rebirth_glow:
            g = pygame.Surface((r.w, r.h), pygame.SRCALPHA)
            g.fill((255, 180, 0, 14))
            surf.blit(g, r.topleft)

# =============================================================
# PANTALLA DE REBIRTH
# =============================================================

class RebirthScreen:
    """Overlay que aparece al hacer Rebirth para confirmar."""

    def __init__(self):
        self.visible  = False
        self.confirm  = False
        self._btn_ok  = pygame.Rect(0, 0, 0, 0)
        self._btn_no  = pygame.Rect(0, 0, 0, 0)
        self._preview = {}   # datos calculados

    def open(self, game):
        self.visible = True
        self.confirm = False
        rb = game.rebirths
        self._preview = {
            "cost_cp":     game.rebirth_cp_cost(),
            "rb":          rb,
            "new_rb":      rb + 1,
            "perm_bonus":  game.prestige_bonus(rb + 1),
            "current_bon": game.prestige_bonus(rb),
            "rebirth_pts": game.rebirth_points + 1,
        }

    def close(self):
        self.visible = False

    def handle_click(self, mx, my) -> str:
        """'ok' | 'cancel' | '' """
        if self._btn_ok.collidepoint(mx, my):
            return "ok"
        if self._btn_no.collidepoint(mx, my):
            return "cancel"
        return ""

    def draw(self, surf):
        if not self.visible:
            return

        # Fondo semitransparente
        ov = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 200))
        surf.blit(ov, (0, 0))

        # Caja central
        W, H = 560, 420
        cx   = ANCHO // 2
        cy   = ALTO  // 2
        box  = pygame.Rect(cx - W//2, cy - H//2, W, H)
        draw_panel(surf, box, PANEL_RB, ORO, 3, 18)

        p = self._preview
        y = box.y + 22

        blit_shadow(surf, "✦ REBIRTH ✦", fuente_titulo, ORO,
                    (0, y), shadow=(80, 40, 0))
        # centra el titulo
        t = fuente_titulo.render("✦ REBIRTH ✦", True, ORO)
        surf.blit(t, (cx - t.get_width()//2, y))
        y += 58

        lineas = [
            ("Coste",        f"{fmt(p['cost_cp'])} CP",        ROJO),
            ("Rebirths",     f"{p['rb']}  →  {p['new_rb']}",   AZUL),
            ("Puntos prestige", f"{p['rebirth_pts']}",          ORO),
            ("Bonus global actual",
             f"x{p['current_bon']:.2f}",                        VERDE),
            ("Bonus global NUEVO",
             f"x{p['perm_bonus']:.2f}  (+{(p['perm_bonus']-p['current_bon'])*100:.0f}%)",
             AMARILLO),
        ]

        for label, val, col in lineas:
            lbl_s = fuente_pequena.render(label + ":", True, GRIS)
            val_s = fuente.render(val, True, col)
            surf.blit(lbl_s, (box.x + 30, y))
            surf.blit(val_s, (box.right - val_s.get_width() - 30, y))
            pygame.draw.line(surf, PANEL2,
                             (box.x+20, y+28), (box.right-20, y+28), 1)
            y += 38

        y += 12

        # Aviso
        warn = fuente_pequena.render(
            "Se reinicia TODO el progreso CP, pero conservas los upgrades de Prestige.",
            True, GRIS)
        surf.blit(warn, (cx - warn.get_width()//2, y))
        y += 34

        # Botones
        BW, BH = 180, 50
        self._btn_ok = pygame.Rect(cx - BW - 16, y, BW, BH)
        self._btn_no = pygame.Rect(cx + 16,       y, BW, BH)

        draw_panel(surf, self._btn_ok, (50, 130, 60), VERDE, 2, 10)
        draw_panel(surf, self._btn_no, (130, 40, 40), ROJO,  2, 10)

        ok_t = fuente.render("CONFIRMAR", True, BLANCO)
        no_t = fuente.render("CANCELAR",  True, BLANCO)
        surf.blit(ok_t, (self._btn_ok.centerx - ok_t.get_width()//2,
                         self._btn_ok.centery - ok_t.get_height()//2))
        surf.blit(no_t, (self._btn_no.centerx - no_t.get_width()//2,
                         self._btn_no.centery - no_t.get_height()//2))

# =============================================================
# JUEGO PRINCIPAL
# =============================================================

class GuitarClicker:

    # ── Constantes de rebirth ──────────────────────────────
    REBIRTH_BASE_COST = 500_000        # CP mínimos para el 1er rebirth
    REBIRTH_COST_MULT = 8.0            # cada rebirth cuesta x8 más
    PRESTIGE_BONUS_PER_RB = 0.40      # +40% global permanente por rebirth

    def __init__(self):
        # ── Recursos ──────────────────────────────────────
        self.cp     = 0.0
        self.tokens = 0.0
        self.total_cp_earned = 0.0    # para calcular rebirth

        # ── Rebirth / Prestige ─────────────────────────────
        self.rebirths       = 0
        self.rebirth_points = 0       # puntos gastables en upgrades prestige
        self.rebirth_pts_spent = 0

        # ── Buffs activos ──────────────────────────────────
        self.cam_timer      = 0       # frames restantes de CAM
        self.cam_activations = 0      # total de veces activada la CAM

        # ── UI ────────────────────────────────────────────
        self.guitar_pulse   = 0
        self.scroll_y       = 0
        self.ninos_tocados  = 0
        self._spawn_counter = 0       # cuenta frames para spawn exacto

        # ── Entidades ──────────────────────────────────────
        self.ninos:     List[Nino]         = []
        self.particles: List[Particle]     = []
        self.floating:  List[FloatingText] = []

        # ── Upgrades normales ──────────────────────────────
        #
        #   EQUILIBRIO:
        #   - Click: base 1 CP  → coste barato,  llega a 3000 CP/click
        #   - CPS:   base 1 CPS → coste moderado, llega a 5000 CPS
        #   - Token: multiplica todo (click + cps)
        #   - Global: bonos multiplicativos de categoría
        #   - Prestige: permanentes tras rebirth

        self.upgrades: Dict[str, Upgrade] = {

            # ── CLICK ─────────────────────────────────────
            "mic":      Upgrade("Microfono",       12,       1.14,     1,    "click", "+1 CP/click"),
            "miniatura":Upgrade("Miniatura",       100,      1.16,     6,    "click", "+6 CP/click"),
            "pc":       Upgrade("PC",              750,      1.19,    28,    "click", "+28 CP/click"),
            "cam":      Upgrade("Cam 4K",        5_500,      1.22,   120,    "click", "+120 CP/click"),
            "estudio":  Upgrade("Estudio",       40_000,     1.25,   650,    "click", "+650 CP/click"),
            "sello":    Upgrade("Sello Disquero",350_000,    1.28,  3_500,   "click", "+3.5K CP/click"),

            # ── CPS ───────────────────────────────────────
            "sub":      Upgrade("Sub",             20,       1.13,     1,    "cps",   "+1 CP/s"),
            "editor":   Upgrade("Editor",         160,       1.16,     8,    "cps",   "+8 CP/s"),
            "canal":    Upgrade("Canal",         1_100,      1.19,    38,    "cps",   "+38 CP/s"),
            "stream":   Upgrade("Stream",        8_000,      1.22,   160,    "cps",   "+160 CP/s"),
            "agencia":  Upgrade("Agencia",       65_000,     1.25,   900,    "cps",   "+900 CP/s"),
            "tour":     Upgrade("Tour Mundial",  550_000,    1.28,  5_500,   "cps",   "+5.5K CP/s"),

            # ── TOKEN → Multiplicador global ──────────────
            "noob":       Upgrade("Niño noob",         6,   1.24,  0.05,  "token", "+5% multi"),
            "pro":        Upgrade("Niño pro",          30,  1.27,  0.10,  "token", "+10% multi"),
            "hacker":     Upgrade("Niño hacker",      110,  1.30,  0.20,  "token", "+20% multi"),
            "dios":       Upgrade("Niño dios",        450,  1.36,  0.40,  "token", "+40% multi"),
            "legendario": Upgrade("Niño legendario", 2_200, 1.42,  1.00,  "token", "+100% multi"),

            # ── GLOBAL (mejoras de categoría) ─────────────
            "cuerdas":  Upgrade("Cuerdas de Oro",    280,   1.20,  0,  "global", "x1.5 todo CP/click/nivel"),
            "amplif":   Upgrade("Amplificador",    2_200,   1.23,  0,  "global", "x1.5 todo CP/s/nivel"),
            "pedal":    Upgrade("Pedal Wah",       16_000,  1.26,  0,  "global", "x2 tokens de niños/nivel"),
            "arena":    Upgrade("Arena Rock",      130_000, 1.30,  0,  "global", "CAM dura +30s/nivel"),

            # ── PRESTIGE (con puntos de rebirth) ──────────
            "estrella": Upgrade("Estrella de Rock",   1,    1.00,  0.10, "prestige", "+10% global permanente"),
            "leyenda":  Upgrade("Leyenda Viral",       3,    1.00,  0.25, "prestige", "+25% global permanente"),
            "diosg":    Upgrade("Dios del Guitar",     8,    1.00,  0.50, "prestige", "+50% global permanente"),
        }

        self._shop_buttons: List[ShopButton] = [
            ShopButton(u) for u in self.upgrades.values()
        ]

        self._sections = [
            ("── Mejoras de Click ──",
             ["mic","miniatura","pc","cam","estudio","sello"]),
            ("── Farmeo Pasivo (CP/s) ──",
             ["sub","editor","canal","stream","agencia","tour"]),
            ("── Mejoras de Token ──",
             ["noob","pro","hacker","dios","legendario"]),
            ("── Mejoras Globales ──",
             ["cuerdas","amplif","pedal","arena"]),
            ("── Prestige (Puntos Rebirth) ──",
             ["estrella","leyenda","diosg"]),
        ]

        self._cam_rect     = pygame.Rect(0,0,0,0)
        self._rebirth_rect = pygame.Rect(0,0,0,0)
        self._rb_screen    = RebirthScreen()

    # ── Serialización (save / load) ───────────────────────

    def save(self):
        data = {
            "cp":              self.cp,
            "tokens":          self.tokens,
            "total_cp_earned": self.total_cp_earned,
            "rebirths":        self.rebirths,
            "rebirth_points":  self.rebirth_points,
            "rebirth_pts_spent": self.rebirth_pts_spent,
            "cam_activations": self.cam_activations,
            "ninos_tocados":   self.ninos_tocados,
            "upgrades":        {k: v.to_dict() for k,v in self.upgrades.items()},
        }
        try:
            with open(SAVE_FILE, "w") as f:
                json.dump(data, f)
        except Exception:
            pass

    def load(self):
        if not os.path.exists(SAVE_FILE):
            return
        try:
            with open(SAVE_FILE) as f:
                data = json.load(f)
            self.cp               = float(data.get("cp", 0))
            self.tokens           = float(data.get("tokens", 0))
            self.total_cp_earned  = float(data.get("total_cp_earned", 0))
            self.rebirths         = int(data.get("rebirths", 0))
            self.rebirth_points   = int(data.get("rebirth_points", 0))
            self.rebirth_pts_spent= int(data.get("rebirth_pts_spent", 0))
            self.cam_activations  = int(data.get("cam_activations", 0))
            self.ninos_tocados    = int(data.get("ninos_tocados", 0))
            for k, v in data.get("upgrades", {}).items():
                if k in self.upgrades:
                    self.upgrades[k].from_dict(v)
            # Reconstruir shop buttons con nuevos upgrades
            self._shop_buttons = [ShopButton(u) for u in self.upgrades.values()]
        except Exception:
            pass

    # ── Fórmulas de Rebirth ────────────────────────────────

    def rebirth_cp_cost(self) -> float:
        return self.REBIRTH_BASE_COST * (self.REBIRTH_COST_MULT ** self.rebirths)

    def prestige_bonus(self, rb_count: int) -> float:
        """Multiplicador global permanente acumulado por rebirths."""
        # Base por rebirths
        rb_base = 1.0 + rb_count * self.PRESTIGE_BONUS_PER_RB
        # Bonus de upgrades prestige permanentes
        prestige_extra = 0.0
        prestige_extra += self.upgrades["estrella"].level * 0.10
        prestige_extra += self.upgrades["leyenda"].level  * 0.25
        prestige_extra += self.upgrades["diosg"].level    * 0.50
        return rb_base * (1.0 + prestige_extra)

    def can_rebirth(self) -> bool:
        return self.cp >= self.rebirth_cp_cost()

    def do_rebirth(self):
        """Ejecuta el rebirth: reinicia progreso, conserva prestige."""
        self.rebirths       += 1
        self.rebirth_points += 1

        # Guardar niveles prestige antes de resetear
        prestige_save = {k: self.upgrades[k].level
                         for k in ["estrella","leyenda","diosg"]}

        # Resetear todo lo no-prestige
        self.cp              = 0.0
        self.tokens          = 0.0
        self.total_cp_earned = 0.0
        self.cam_timer       = 0
        self.ninos           = []
        self.particles       = []
        self.floating        = []
        self._spawn_counter  = 0

        for k, u in self.upgrades.items():
            if u.tipo != "prestige":
                u.level = 0

        # Restaurar prestige
        for k, lvl in prestige_save.items():
            self.upgrades[k].level = lvl

        self._shop_buttons = [ShopButton(u) for u in self.upgrades.values()]
        self.save()

    # ── Getters de multiplicadores ─────────────────────────

    def _glvl(self, key) -> int:
        return self.upgrades[key].level

    def total_multiplier(self) -> float:
        # Token upgrades
        m = 1.0
        for u in self.upgrades.values():
            if u.tipo == "token":
                m += u.power * u.level
        # CAM buff
        if self.cam_timer > 0:
            m *= 2.5
        # Prestige permanente
        m *= self.prestige_bonus(self.rebirths)
        return m

    def click_mult(self) -> float:
        lvl = self._glvl("cuerdas")
        return (1.5 ** lvl) if lvl else 1.0

    def cps_mult(self) -> float:
        lvl = self._glvl("amplif")
        return (1.5 ** lvl) if lvl else 1.0

    def token_mult(self) -> float:
        lvl = self._glvl("pedal")
        return (2.0 ** lvl) if lvl else 1.0

    def cam_duration(self) -> int:
        base_s = 60 + self._glvl("arena") * 30
        return base_s * FPS

    def cam_cost(self) -> int:
        # Escala con cuántas veces la has activado
        return int(80 * (1.6 ** self.cam_activations))

    def cps(self) -> float:
        raw = sum(u.power * u.level
                  for u in self.upgrades.values()
                  if u.tipo == "cps")
        return raw * self.total_multiplier() * self.cps_mult()

    def power(self) -> float:
        raw = 1.0 + sum(u.power * u.level
                        for u in self.upgrades.values()
                        if u.tipo == "click")
        return raw * self.total_multiplier() * self.click_mult()

    def rebirth_bonus_display(self) -> float:
        return self.prestige_bonus(self.rebirths)

    # ── Acciones ──────────────────────────────────────────

    def click_guitar(self, mx, my):
        gain = self.power()
        self.cp              += gain
        self.total_cp_earned += gain
        self.guitar_pulse     = 10

        self.floating.append(FloatingText(
            f"+{fmt(gain)} CP", mx, my - 55, VERDE, big=True))

        # Más partículas si la CAM está activa
        n_part = 18 if self.cam_timer > 0 else 10
        cols   = [AZUL, VERDE, CYAN, (100, 255, 200)]
        for _ in range(n_part):
            self.particles.append(Particle(mx, my, random.choice(cols)))

    def click_nino(self, nino: Nino):
        gain = max(1, int(nino.valor
                          * self.total_multiplier()
                          * self.token_mult()))
        self.tokens        += gain
        self.ninos_tocados += 1

        cx = int(nino.x + NINO_SIZE//2)
        cy = int(nino.y + NINO_SIZE//2)
        self.floating.append(FloatingText(
            f"+{fmt(gain)} TK", cx, cy - 28, AMARILLO))
        for _ in range(10):
            self.particles.append(
                Particle(cx, cy, nino.border_col, speed_mult=1.2))

    def activate_cam(self):
        cost = self.cam_cost()
        if self.tokens >= cost:
            self.tokens          -= cost
            self.cam_activations += 1
            self.cam_timer        = self.cam_duration()
            # Partículas de activación
            for _ in range(30):
                self.particles.append(
                    Particle(GX, GY, AZUL, speed_mult=2.0))
            self.floating.append(
                FloatingText("¡CAM ACTIVADA! x2.5", GX, GY-80, AZUL, big=True))

    def buy_upgrade(self, upg: Upgrade) -> bool:
        if upg.tipo == "prestige":
            cost = upg.cost()
            pts_avail = self.rebirth_points - self.rebirth_pts_spent
            if pts_avail >= cost:
                self.rebirth_pts_spent += cost
                upg.level += 1
                return True
            return False

        cost = upg.cost()
        if upg.tipo == "token":
            if self.tokens >= cost:
                self.tokens -= cost
                upg.level   += 1
                return True
        else:
            if self.cp >= cost:
                self.cp   -= cost
                upg.level += 1
                return True
        return False

    # ── Update ────────────────────────────────────────────

    def update(self, mx, my):
        # CP pasivo
        gained = self.cps() / FPS
        self.cp              += gained
        self.total_cp_earned += gained

        # Timers
        if self.cam_timer    > 0: self.cam_timer    -= 1
        if self.guitar_pulse > 0: self.guitar_pulse -= 1

        # Spawn de niños: 1 cada SPAWN_INTERVAL frames exactos
        self._spawn_counter += 1
        if self._spawn_counter >= SPAWN_INTERVAL and len(self.ninos) < MAX_NINOS:
            self._spawn_counter = 0
            rb_bonus = 1.0 + self.rebirths * 0.3   # niños más valiosos con rebirth
            self.ninos.append(Nino(rebirth_bonus=rb_bonus))

        for n in self.ninos:
            n.update(mx, my)

        self.particles = [p for p in self.particles if p.life > 0]
        for p in self.particles:
            p.update()

        self.floating = [f for f in self.floating if f.life > 0]
        for f in self.floating:
            f.update()

    # ── Draw principal ────────────────────────────────────

    def draw(self, surf, mx, my):
        surf.fill(FONDO)
        self._draw_left(surf)
        self._draw_center(surf)
        self._draw_right(surf, mx, my)

        for n in self.ninos:
            n.draw(surf)
        for p in self.particles:
            p.draw(surf)
        for f in self.floating:
            f.draw(surf)

        # Pantalla rebirth encima de todo
        self._rb_screen.draw(surf)

    # ── Panel izquierdo ───────────────────────────────────

    def _draw_left(self, surf):
        pygame.draw.rect(surf, PANEL, (0, 0, LEFT_W, ALTO))
        pygame.draw.line(surf, PANEL2, (LEFT_W-1, 0), (LEFT_W-1, ALTO), 2)

        # Título con rebirth glow si tiene rebirths
        title_col = ORO if self.rebirths > 0 else AMARILLO
        blit_shadow(surf, "GUITAR CLICKER", fuente, title_col, (14, 10))

        if self.rebirths > 0:
            rb_badge = fuente_mini.render(
                f"✦ Prestige {self.rebirths}", True, ORO)
            surf.blit(rb_badge, (14, 36))
            offset_y = 52
        else:
            offset_y = 44

        cam_on = self.cam_timer > 0

        stats = [
            ("CP TOTAL",       fmt(self.cp),                          VERDE),
            ("TOKENS",         fmt(self.tokens),                      AMARILLO),
            ("CAM ACTIVADA",
             f"{int(self.cam_timer/FPS)}s" if cam_on else "NO",
             AZUL if cam_on else GRIS),
            ("CP / s",         fmt(self.cps()),                       CYAN),
            ("CLICK POWER",    fmt(self.power()),                     BLANCO),
            ("MULTIPLICADOR",  f"x{self.total_multiplier():.2f}",    MORADO),
            ("PRESTIGE BONUS", f"x{self.rebirth_bonus_display():.2f}", ORO),
        ]

        y = offset_y
        for titulo, valor, color in stats:
            rect   = pygame.Rect(8, y, LEFT_W - 16, 70)
            border = (AZUL if cam_on and titulo == "CAM ACTIVADA"
                      else ORO if titulo == "PRESTIGE BONUS" and self.rebirths > 0
                      else PANEL3)
            draw_panel(surf, rect, PANEL2, border, 2, 10)
            blit_shadow(surf, titulo, fuente_micro, GRIS, (18, y + 7))
            blit_shadow(surf, valor,  fuente_grande, color, (18, y + 30))
            y += 76

        # Glow CAM
        if cam_on:
            t     = pygame.time.get_ticks() * 0.005
            alpha = int(12 + 10 * math.sin(t))
            glow  = pygame.Surface((LEFT_W, ALTO), pygame.SRCALPHA)
            glow.fill((0, 180, 255, alpha))
            surf.blit(glow, (0, 0))

    # ── Panel central ──────────────────────────────────────

    def _draw_center(self, surf):
        pygame.draw.rect(surf, (9, 14, 28), (CENTER_X, 0, CENTER_W, ALTO))

        # Color de los anillos según rebirth
        ring_col = lerp_color(AZUL, ORO, min(1.0, self.rebirths / 5))
        t = pygame.time.get_ticks() * 0.001
        for i in range(5, 0, -1):
            r = int(GUITAR_HIT_R * i / 5 + 10 * math.sin(t + i * 0.8))
            a = 8 + i * 4
            s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
            pygame.draw.circle(s, (*ring_col, a), (r, r), r)
            surf.blit(s, (GX - r, GY - r))

        # Imagen con pulso
        scale = (1.0 + 0.10 * self.guitar_pulse / 10
                 if self.guitar_pulse > 0 else 1.0)
        size  = int(300 * scale)
        img   = pygame.transform.smoothscale(img_guitar_orig, (size, size))

        rot = math.sin(pygame.time.get_ticks() * 0.0007) * 2.0
        if self.guitar_pulse > 0:
            rot += self.guitar_pulse * 1.8
        img  = pygame.transform.rotate(img, rot)
        rect = img.get_rect(center=(GX, GY))
        surf.blit(img, rect)

        # Indicador de progreso rebirth
        rb_cost = self.rebirth_cp_cost()
        prog    = min(1.0, self.cp / rb_cost)
        bar_w   = 260
        bar_h   = 10
        bx      = GX - bar_w // 2
        by      = ALTO - 55
        pygame.draw.rect(surf, PANEL2, (bx, by, bar_w, bar_h), border_radius=5)
        if prog > 0:
            bar_col = lerp_color(AZUL, ORO, prog)
            pygame.draw.rect(surf, bar_col,
                             (bx, by, int(bar_w * prog), bar_h),
                             border_radius=5)
        pygame.draw.rect(surf, GRIS_O, (bx, by, bar_w, bar_h), 1, border_radius=5)

        rb_lbl = fuente_micro.render(
            f"Rebirth: {fmt(self.cp)} / {fmt(rb_cost)} CP  ({prog*100:.1f}%)",
            True, ORO if prog >= 1.0 else GRIS)
        surf.blit(rb_lbl, (GX - rb_lbl.get_width()//2, by + 14))

        hint = fuente_mini.render("¡Haz clic para ganar CP!", True, GRIS)
        surf.blit(hint, (GX - hint.get_width()//2, ALTO - 22))

    # ── Panel derecho ──────────────────────────────────────

    def _draw_right(self, surf, mx, my):
        pygame.draw.rect(surf, PANEL, (RIGHT_X, 0, RIGHT_W, ALTO))
        pygame.draw.line(surf, PANEL2, (RIGHT_X, 0), (RIGHT_X, ALTO), 2)

        # Estadísticas
        blit_shadow(surf, "ESTADISTICAS", fuente,
                    AMARILLO, (RIGHT_X + 14, 8))

        pts_libres = self.rebirth_points - self.rebirth_pts_spent
        stat_rows  = [
            ("Multiplicador",     f"x{self.total_multiplier():.2f}",     VERDE),
            ("Niños tocados",     str(self.ninos_tocados),                AZUL),
            ("Niños en pantalla", str(len(self.ninos)),                   MORADO),
            ("Click bonus",       f"x{self.click_mult():.1f}",            CYAN),
            ("CPS bonus",         f"x{self.cps_mult():.1f}",              NARANJA),
            ("Token bonus",       f"x{self.token_mult():.1f}",            AMARILLO),
            ("Rebirths",          str(self.rebirths),                     ORO),
            ("Puntos prestige",   f"{pts_libres} / {self.rebirth_points}",ORO),
        ]

        y = 36
        for lbl, val, col in stat_rows:
            blit_shadow(surf, lbl + ":", fuente_micro, GRIS, (RIGHT_X+10, y))
            blit_shadow(surf, val, fuente_pequena, col, (RIGHT_X+10, y+14))
            y += 34

        # Botón CAM
        cost_cam = self.cam_cost()
        can_cam  = self.tokens >= cost_cam
        cam_dur  = (60 + self._glvl("arena") * 30)
        cam_rect = pygame.Rect(RIGHT_X + 8, y + 4, RIGHT_W - 16, 46)
        hov_cam  = cam_rect.collidepoint(mx, my)

        cfill  = ((48, 138, 75) if hov_cam and can_cam else
                  (36, 105, 58) if can_cam else PANEL2)
        cbord  = VERDE if can_cam else ROJO
        draw_panel(surf, cam_rect, cfill, cbord, 2, 9)

        cl1 = fuente_pequena.render("ACTIVAR CAM  x2.5", True, BLANCO)
        cl2 = fuente_micro.render(
            f"{fmt(cost_cam)} TK  |  dura {cam_dur}s", True,
            AMARILLO if can_cam else GRIS)
        surf.blit(cl1, (cam_rect.centerx - cl1.get_width()//2, cam_rect.y+5))
        surf.blit(cl2, (cam_rect.centerx - cl2.get_width()//2, cam_rect.y+25))
        self._cam_rect = cam_rect

        # Botón REBIRTH
        rb_cost  = self.rebirth_cp_cost()
        can_rb   = self.can_rebirth()
        rb_y     = cam_rect.bottom + 4
        rb_rect  = pygame.Rect(RIGHT_X + 8, rb_y, RIGHT_W - 16, 46)
        hov_rb   = rb_rect.collidepoint(mx, my)

        # Parpadeo dorado si puede hacer rebirth
        t_ms = pygame.time.get_ticks()
        if can_rb:
            pulse = abs(math.sin(t_ms * 0.003))
            rb_fill = lerp_color((80, 55, 10), (130, 95, 20), pulse)
        else:
            rb_fill = PANEL_RB if hov_rb else (28, 14, 44)
        rb_bord = ORO if can_rb else (100, 60, 120)

        draw_panel(surf, rb_rect, rb_fill, rb_bord, 2, 9)

        rb_txt1 = fuente_pequena.render("✦ REBIRTH ✦", True,
                                        ORO if can_rb else GRIS)
        rb_txt2 = fuente_micro.render(
            f"{fmt(rb_cost)} CP  |  Bonus x{self.prestige_bonus(self.rebirths+1):.2f}",
            True, AMARILLO if can_rb else GRIS)
        surf.blit(rb_txt1, (rb_rect.centerx - rb_txt1.get_width()//2, rb_rect.y+5))
        surf.blit(rb_txt2, (rb_rect.centerx - rb_txt2.get_width()//2, rb_rect.y+25))
        self._rebirth_rect = rb_rect

        # Tienda con scroll
        shop_top    = rb_rect.bottom + 6
        shop_area_h = ALTO - shop_top
        clip        = pygame.Rect(RIGHT_X, shop_top, RIGHT_W, shop_area_h)
        surf.set_clip(clip)

        blit_shadow(surf, "TIENDA", fuente, AMARILLO,
                    (RIGHT_X+14, shop_top + 3 - self.scroll_y))

        btn_idx = 0
        cur_y   = shop_top + 32 - self.scroll_y

        pts_libres_disp = self.rebirth_points - self.rebirth_pts_spent

        for sec_title, keys in self._sections:
            sh = fuente_micro.render(sec_title, True, GRIS)
            surf.blit(sh, (RIGHT_X+12, cur_y))
            cur_y += 18

            for k in keys:
                upg = self.upgrades[k]
                btn = self._shop_buttons[btn_idx]
                btn.reposition(RIGHT_X + 14, cur_y)

                if cur_y + SHOP_H > shop_top and cur_y < ALTO:
                    if upg.tipo == "prestige":
                        can = pts_libres_disp >= upg.cost()
                    elif upg.tipo == "token":
                        can = self.tokens >= upg.cost()
                    else:
                        can = self.cp >= upg.cost()

                    hov = btn.rect.collidepoint(mx, my)
                    btn.draw(surf, can, hov,
                             self.cam_timer > 0,
                             rebirth_glow=(upg.tipo == "prestige"))

                cur_y   += SHOP_H + SHOP_PAD
                btn_idx += 1

            cur_y += 5

        surf.set_clip(None)
        max_scroll = max(0, cur_y + self.scroll_y - shop_top - shop_area_h)
        self.scroll_y = min(self.scroll_y, max_scroll)

    # ── Hit testing ───────────────────────────────────────

    def is_guitar_click(self, mx, my) -> bool:
        return math.hypot(mx - GX, my - GY) < GUITAR_HIT_R

    def get_nino_at(self, mx, my) -> Optional[Nino]:
        for n in self.ninos:
            if n.rect.collidepoint(mx, my):
                return n
        return None

    def get_shop_btn_at(self, mx, my) -> Optional[ShopButton]:
        for btn in self._shop_buttons:
            if btn.rect.collidepoint(mx, my):
                return btn
        return None

    def is_cam_btn(self, mx, my) -> bool:
        return self._cam_rect.collidepoint(mx, my)

    def is_rebirth_btn(self, mx, my) -> bool:
        return self._rebirth_rect.collidepoint(mx, my)

    def handle_rebirth_click(self, mx, my):
        if self._rb_screen.visible:
            action = self._rb_screen.handle_click(mx, my)
            if action == "ok":
                self.do_rebirth()
                self._rb_screen.close()
            elif action == "cancel":
                self._rb_screen.close()
        elif self.is_rebirth_btn(mx, my):
            if self.can_rebirth():
                self._rb_screen.open(self)

# =============================================================
# MAIN LOOP
# =============================================================

def main():
    game = GuitarClicker()
    game.load()

    save_timer = 0
    SAVE_EVERY = 30 * FPS   # auto-save cada 30 s

    while True:
        mx, my = pygame.mouse.get_pos()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                game.save()
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s and \
                   pygame.key.get_mods() & pygame.KMOD_CTRL:
                    game.save()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

                # Si el rebirth screen está abierto, captura todos los clics
                if game._rb_screen.visible:
                    game.handle_rebirth_click(mx, my)
                else:
                    # Niños (prioridad)
                    nino = game.get_nino_at(mx, my)
                    if nino:
                        game.click_nino(nino)
                        game.ninos.remove(nino)
                    elif game.is_guitar_click(mx, my):
                        game.click_guitar(mx, my)

                    # CAM
                    if game.is_cam_btn(mx, my):
                        game.activate_cam()

                    # Rebirth
                    game.handle_rebirth_click(mx, my)

                    # Tienda
                    btn = game.get_shop_btn_at(mx, my)
                    if btn:
                        game.buy_upgrade(btn.upg)

            if event.type == pygame.MOUSEWHEEL and mx > RIGHT_X:
                game.scroll_y -= event.y * 30
                if game.scroll_y < 0:
                    game.scroll_y = 0

        game.update(mx, my)
        game.draw(pantalla, mx, my)
        pygame.display.flip()
        reloj.tick(FPS)

        # Auto-save
        save_timer += 1
        if save_timer >= SAVE_EVERY:
            save_timer = 0
            game.save()

# =============================================================

if __name__ == "__main__":
    main()
